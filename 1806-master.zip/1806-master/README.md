# MIT Course 18.06, Spring 2020 

This is a repository for the course [18.06: Linear Algebra](http://web.mit.edu/18.06) at MIT in Spring 2020.

See [the syllabus and lecture summaries](summaries.md) for the main course pages.
